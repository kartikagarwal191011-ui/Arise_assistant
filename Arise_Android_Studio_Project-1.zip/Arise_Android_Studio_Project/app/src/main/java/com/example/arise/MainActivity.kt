package com.example.arise

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.graphics.Color
import android.net.Uri
import android.widget.*
import java.text.DateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var output: TextView
    private lateinit var input: EditText
    private lateinit var status: TextView
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var waitingForWakeCommand = false
    private val bg = Color.rgb(7, 17, 31)
    private val panel = Color.rgb(16, 30, 48)
    private val cyan = Color.rgb(97, 231, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status.text = "Listening… say “Arise” followed by a command" }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { status.text = "Processing voice…" }
                override fun onError(error: Int) { status.text = "Voice input ended. Tap Listen again or type." }
                override fun onResults(results: Bundle?) {
                    val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    val cleaned = heard.trim()
                    if (waitingForWakeCommand) {
                        waitingForWakeCommand = false
                        if (cleaned.startsWith("arise", ignoreCase = true)) {
                            val command = cleaned.replaceFirst(Regex("^arise[ ,.!:-]*", RegexOption.IGNORE_CASE), "").trim()
                            if (command.isNotBlank()) handleQuestion(command)
                            else { status.text = "Wake word heard. Tap Listen and say your command." ; reply("I heard Arise. Tap Listen again and say your command.") }
                        } else {
                            status.text = "Didn't hear “Arise”. Tap Listen to try again."
                            reply("I didn't hear the wake word Arise. Please try again.")
                        }
                    } else if (cleaned.isNotBlank()) handleQuestion(cleaned)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        } else {
            status.text = "Speech recognition isn't available on this device."
        }
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(26), dp(20), dp(20))
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "◉  ARISE"
            textSize = 30f
            setTextColor(cyan)
            gravity = Gravity.CENTER_VERTICAL
        }
        val subtitle = TextView(this).apply {
            text = "PERSONAL AI ASSISTANT • STARTER"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(5), 0, dp(14))
        }
        status = TextView(this).apply {
            text = "Ready"
            textSize = 14f
            setTextColor(cyan)
            setPadding(0, dp(8), 0, dp(8))
        }
        output = TextView(this).apply {
            text = "Hello! I'm Arise. Ask a question, say “Arise” after tapping Listen, or use web search."
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(panel)
            minHeight = dp(170)
            gravity = Gravity.TOP
        }
        input = EditText(this).apply {
            hint = "Type your question…"
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            textSize = 16f
            setSingleLine(false)
            setBackgroundColor(panel)
        }
        val send = makeButton("Send") {
            val q = input.text.toString().trim()
            if (q.isNotBlank()) {
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                    .hideSoftInputFromWindow(input.windowToken, 0)
                handleQuestion(q)
            }
        }
        val listen = makeButton("🎙 Listen for Arise") { startListeningForWakeWord() }
        val web = makeButton("Search the internet") {
            val q = input.text.toString().trim()
            if (q.isNotBlank()) openSearch(q) else openSearch("latest news")
        }
        val stop = makeButton("Stop voice") {
            try { recognizer?.cancel() } catch (_: Exception) {}
            tts?.stop()
            status.text = "Stopped"
        }
        val note = TextView(this).apply {
            text = "Internet search opens your browser. This starter does not yet have a connected AI model. Wake-word listening starts only after you tap the button and is not active with the app closed or screen off."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(14), 0, 0)
        }
        outer.addView(title)
        outer.addView(subtitle)
        outer.addView(status)
        outer.addView(output, LinearLayout.LayoutParams(-1, 0, 1f))
        outer.addView(input, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(12) })
        outer.addView(send, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) })
        outer.addView(listen, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) })
        outer.addView(web, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) })
        outer.addView(stop, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) })
        outer.addView(note)
        setContentView(outer)
    }

    private fun makeButton(label: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 14f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(19, 61, 83))
            setOnClickListener { action() }
        }
    }

    private fun startListeningForWakeWord() {
        if (recognizer == null) {
            status.text = "Speech recognition unavailable. Please type."
            return
        }
        waitingForWakeCommand = true
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Say: Arise, followed by your question")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try { recognizer?.startListening(intent) }
        catch (_: Exception) { status.text = "Couldn't start voice input. Try again." }
    }

    private fun handleQuestion(question: String) {
        input.setText("")
        val q = question.trim()
        val lower = q.lowercase(Locale.ROOT)
        val answer = when {
            lower.contains("time") -> "The time is " + DateFormat.getTimeInstance(DateFormat.SHORT).format(Date())
            lower.contains("date") || lower.contains("today") -> "Today is " + DateFormat.getDateInstance(DateFormat.FULL).format(Date())
            lower == "hello" || lower == "hi" || lower.startsWith("hello ") -> "Hello! What can I help you with?"
            lower == "help" || lower.contains("what can you do") -> "I can tell the time and date, speak short replies, and search the internet. Full AI answers will need an AI service connection."
            lower.startsWith("search ") -> { openSearch(q.removePrefix("search ")); "I opened a web search for your question." }
            else -> { openSearch(q); "I can't answer that with built-in knowledge yet, so I opened an internet search. Full AI answers are a later setup step." }
        }
        reply(answer)
    }

    private fun openSearch(query: String) {
        val uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))
        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
        catch (_: Exception) { status.text = "Couldn't open a browser." }
    }

    private fun reply(text: String) {
        output.text = text
        status.text = "Ready"
        if (tts != null) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "arise-answer")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts?.language = Locale("en", "IN")
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        try { recognizer?.destroy() } catch (_: Exception) {}
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) {}
        super.onDestroy()
    }
}
