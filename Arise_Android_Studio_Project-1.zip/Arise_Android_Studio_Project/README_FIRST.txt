ARISE ANDROID PROJECT — STARTER, NOT A FINISHED AI ASSISTANT

WHAT THIS SOURCE PROJECT DOES
- Native Android app UI
- Internet permission
- Uses Android speech recognition after you tap “Listen for Arise”
- Uses Android text-to-speech
- Built-in time/date responses
- Opens browser search for other questions

WHAT IT DOES NOT DO YET
- It does not call an AI model yet, so it cannot generate full AI answers.
- It does not have an always-on wake word. Tap-to-listen is the starter version.
- An APK is not included because an Android build environment is needed to compile and test it.
- No app has unlimited access to Android. Permissions must be requested and the operating system limits microphone/background access.

HOW TO BUILD AN APK ON WINDOWS
1. Install Android Studio from https://developer.android.com/studio
2. Extract the ZIP file.
3. In Android Studio choose Open, then select the extracted Arise_Android_Studio_Project folder.
4. Allow Gradle sync and any required SDK download to finish.
5. Connect your Android phone by USB, enable Developer options and USB debugging only if you are comfortable doing so; alternatively use an emulator.
6. Select Run to test. To create an APK, choose Build > Build Bundle(s) / APK(s) > Build APK(s).
7. Android Studio will show where it saved the APK.

FULL AI CONNECTION
A real AI answer engine needs an AI provider and usually a secure backend. Do not put a private API key inside the APK. API usage may cost money and quotas/pricing can change. A 100% free, unlimited AI service cannot be promised.

WAKE WORD
Android restricts microphone use from the background. The current version asks you to tap the listening button. Always-on activation while the app is closed or screen off requires a more complex design and may not be allowed in all states/devices.
